# Operating rules — read before the step below

You are one step in an automated 15-step redesign of Agent Room, a Tauri +
React 19 desktop app. You run in a **fresh process with no memory of any previous
step**. The repository is the only state. The step brief follows these rules.

## Hard rules

1. **Read only the files in the step's Read allowlist.** Do not explore. Do not
   `Read` `node_modules/`, `dist/`, `.git/`, `src-tauri/target/`, lockfiles, or
   any spec document the step did not name. If you believe you need a file that
   is not listed, stop and say so in your summary instead of reading it.
2. **Write only the files in the step's Write allowlist.** Creating a file
   outside it is a failure, even a helpful one. No `README`s, no scratch files,
   no `*.bak`.
3. **Do not run the gate.** No `npm run build`, no `npm test`, no `tsc`, no
   `npm run tauri dev`, no dev server. The driver runs verification after you
   exit and will hand you the output if it fails. Running them yourself burns
   tokens on output you were not asked to read.
4. **Do not commit.** The driver commits.
5. **Do not reformat, re-sort imports, or "tidy" code you were not asked to
   change.** A diff that touches lines the step did not require is noise and
   makes review impossible.
6. **Behaviour is frozen.** Props, state shape, `native.ts` calls, Tauri command
   names, event names, the SQLite schema and every string crossing the JS↔Rust
   boundary are unchanged unless the step explicitly says otherwise. This is a
   presentation redesign.
7. **Accessibility is not optional.** Every `role`, `aria-*`, `id`/`htmlFor`
   pairing, focus behaviour and keyboard shortcut that exists before your step
   must still exist after it.
8. **No new runtime dependencies.** `package.json` `dependencies` is frozen.
   Only step 14 may add a `devDependency`.
9. **No raw design values.** Outside `src/design/`, never write a hex colour, an
   `rgb()`/`hsl()` literal, a `px` border-radius, a font-family, a raw duration
   or a raw `cubic-bezier`. Use the tokens. `scripts/check-design.mjs` fails the
   gate if you do.
10. **When the step is done, stop.** Do not continue into the next step's work
    because it seems obvious. Steps are ordered for a reason.

## Design skills

If a `frontend-design` or `ui-ux-pro-max-skill` skill is available to you, **use
it** on any step that involves visual design, layout, typography or colour --
which is most of steps 04 through 15. Read it once, at the start, alongside the
step's specification documents.

Where the skill and this repository's `docs/redesign/01-design-language.md`
disagree on a specific value, the design language document wins: its tokens are
already committed to across fifteen steps and changing one mid-run splits the
design. Use the skill for judgement -- composition, hierarchy, restraint, what to
delete -- not for re-deciding the palette.

If neither skill is available, proceed. The specification is self-contained.

## Reading efficiently

- Prefer `Grep` to locate, then `Read` with `offset`/`limit`. Do not read a
  2,000-line file to change 40 lines of it.
- When the step gives you line anchors, trust them and read that region only.
- Read a specification document once, fully, at the start. Do not re-read it.

## Your output

When you finish, print **at most 12 lines**: what you changed, any spec detail
you had to interpret, and anything the next step must know. No code in the
summary. No file listings. No congratulation.

If you could not complete the step, say exactly which part is unfinished and
why, in one paragraph, and leave the repository in a state that still builds.

## If the driver hands you a failure

You will get the step brief again plus the failing command output. Fix **only**
what the output names. Do not take the opportunity to improve anything else. Do
not re-read files you do not need to change.
