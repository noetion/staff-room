---
id: "01"
title: "Design foundation — tokens, glass, base, theming"
budget: 25000
gate: ["tsc", "test", "build", "design-lint"]
optional: false
visual: false
model: "terra"
effort: "medium"
---

# Step 01 — Design foundation

Build the token and material layer. Wire it in **alongside** the existing
stylesheet so the app keeps working. Nothing visual is rewired yet.

## Read

- `docs/redesign/01-design-language.md`
- `docs/redesign/02-materials.md`
- `src/main.tsx`
- `index.html`
- `src-tauri/tauri.conf.json`

Do **not** read `src/App.tsx` or `src/styles.css` in this step.

## Write

- `src/design/tokens.css` (new)
- `src/design/glass.css` (new)
- `src/design/base.css` (new)
- `src/design/index.css` (new)
- `src/main.tsx`
- `index.html`
- `src-tauri/tauri.conf.json`

## Task

**`src/design/tokens.css`** — transcribe §1–§6 of the design language document
into custom properties on `:root`. Every table row becomes a token. Structure:

- `:root` holds the light values plus all theme-independent tokens (space,
  radius, type scale, motion).
- `:root[data-theme="dark"]` overrides only the colour and elevation tokens.
- `@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { … } }`
  applies the dark set when the user has not chosen explicitly. Do this by
  assigning the same block, not by duplicating values — define the dark values
  once in a `%`-style reusable position if your CSS allows, otherwise accept one
  duplication and add a comment saying the two blocks must stay in sync.
- Include `color-scheme: light dark;` on `:root` so native scrollbars and form
  controls follow.

Name tokens exactly as the document names them. The rest of the redesign
references these strings literally.

**`src/design/glass.css`** — the `.glass`, `.glass--clear`, `.glass::after`
specular sweep, `.scroll-edge` variants, the `@supports (backdrop-filter: url())`
refraction hook (the filter element itself arrives in step 12), and all four
fallback blocks from §"Fallbacks". The fallbacks are mandatory now, not later.

**`src/design/base.css`** — a minimal reset (`box-sizing`, margin zeroing, `img`
and `svg` block display), `html`/`body`/`#root` at full height with `--ground` as
background, base typography from the tokens, a single global focus style
(`:focus-visible` → 2px `--state-working` ring, 2px offset, `--r-*` inherited),
custom scrollbar styling in both themes, `::selection`, and the
`prefers-reduced-motion` global damper.

**`src/design/index.css`** — imports tokens, glass, base, in that order, and
nothing else.

**`src/main.tsx`** — import `./design/index.css` **before** `./styles.css` so the
old sheet still wins for now. Keep the font imports. Add a small boot routine
before `createRoot` that reads `localStorage.getItem("ar-theme")`
(`"light" | "dark" | "system"`, default `"system"`) and sets `data-theme` on
`document.documentElement` accordingly; `"system"` sets no attribute.

**`index.html`** — replace the `theme-color` meta with two, one per
`prefers-color-scheme`, using the ground colours. Add
`<meta name="color-scheme" content="light dark">`.

**`src-tauri/tauri.conf.json`** — change `backgroundColor` from `#141412` to the
light ground `#E9E6EE`. Change nothing else in this file. Do not add
`windowEffects` in this step.

`scripts/check-design.mjs` already exists in the repository and is used by the
gate. **Do not create, modify or read it.** Your job is only to make the token
layer it checks for.

## Acceptance

1. `npm run dev` would render the app exactly as before — the old stylesheet is
   still authoritative.
2. Every token named in `01-design-language.md` exists in `tokens.css` with the
   documented value.
3. Toggling `document.documentElement.dataset.theme` between `light` and `dark`
   in the console changes every token in `tokens.css`.
4. `.glass` renders as translucent blurred glass in Chromium and as solid
   `--surface` under each of the four fallback conditions.
5. The design lint passes (the driver runs it; you do not).

## Notes for the next step

Record in your summary the exact class names you exposed in `glass.css`, since
step 02 builds `Surface.tsx` on top of them.
